/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author Lenovo
 */
public class Cart extends Product{
    Scanner in=new Scanner(System.in);
   protected int customerid;
   protected int nProduct;
   protected Product[]Products;
   
   public Cart(){
       
   }
   
    public Cart(int customerid, int nProduct, Product[]Products) {
        this.customerid = customerid;
        this.nProduct = nProduct;
        this.Products = new Product[nProduct];
    }

    public void setCustomerid(int customerid) {
       if(customerid>0) {this.customerid = customerid;}
       else{this.customerid =Math.abs(customerid);}
    }
   
    public int getCustomerid() {
        return customerid;
    }
    
    public void setnProduct(int nProduct) {
      if(nProduct>0)  {this.nProduct = nProduct;}
      else{this.nProduct =Math.abs(nProduct);}
      
    }

    public int getnProduct() {
        return nProduct;
    }
    
    public void setProducts(Product[]Products) {
        this.Products =new Product[nProduct]; ;
    }

    public Product[] getProducts() {
        return Products;
    }
    
   public void addProduct(Product[]Products){
       System.out.println("");
   }
  

    
   
   
    
   
}
