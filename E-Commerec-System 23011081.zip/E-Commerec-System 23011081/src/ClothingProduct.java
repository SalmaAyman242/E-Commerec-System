/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Lenovo
 */
public class ClothingProduct extends Product {
    protected String size;
    protected String frabic;
    
    public ClothingProduct(){
    
    }

    public ClothingProduct(String size, String frabic, int productid, String name, float price) {
        super(productid, name, price);
        this.size = size;
        this.frabic = frabic;
    }
    
     public void setSize(String size) {
        this.size = size;
    }

    public String getSize() {
        return size;
    }
    
    public void setFrabic(String frabic) {
        this.frabic = frabic;
    }
    

    public String getFrabic() {
        return frabic;
    }

    
    
    
    
    
    
    
}
