/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication11;

import java.util.Scanner;


/**
 *
 * @author Lenovo
 */
public class Cart extends Product{
    Scanner in=new Scanner(System.in);
   private int customerid;
   private int nProduct;
   Product[]Products;
   private int counter=0;
   
  
   public Cart(){
       
   }
   
    public Cart(int customerid, int nProduct, Product[]Products) {
        this.customerid = customerid;
        this.nProduct = nProduct;
        this.Products = new Product[this.nProduct];
    }

    public void setCustomerid(int customerid) {
       if(customerid>0) {this.customerid = customerid;}
       else{this.customerid =Math.abs(customerid);}
    }
   
    public int getCustomerid() {
        return customerid;
    }
    
    public void setnProduct(int nProduct) {
      if(nProduct>0)  {this.nProduct = nProduct;}
      else{this.nProduct =Math.abs(nProduct);}
      Products=new Product[nProduct];
    }

    public int getnProduct() {
        return nProduct;
    }
    
    public void setProducts(Product[]Products) {
      this.Products = new Product[this.nProduct];
    }

    public Product[] getProducts() {
         return Products;
        /*for(int j=0;j<Products.length;j++){
            System.out.println(Products[j]);
        */
        
    }
    
   /*public void addProduct(Product p){
       this.Products[counter]=p;
       counter++;

    }*/
    
    
    public void addProduct(Product product) {
          /*this.Products[counter]=product;
           counter++;*/
       for (int i = 0; i < Products.length; i++) {
            if (Products[i] == null) {
                Products[i] = product;
                return;
            }
        }
       System.out.println("the cart is fall canot add  more product");
       
    }
    
    
    public void removeProduct(Product product) {
        for (int i = 0; i < Products.length; i++) {
            if (Products[i] != null && Products[i].equals(product)) {
                Products[i] = null;
                break;
            }
        }
    }
    
    public double calculatePrice() {
        double totalPrice = 0.0;
        for (Product product : Products) {
            if (product != null) {
                totalPrice += product.getPrice();
            }
        }
        return totalPrice;
    }
    
    
    
    

      
    
   /* public void removeProduct(Product p){
      this.Products[counter]=p;
       counter--;
   }*/
 
   /*public void callculateprice(Product p){
    for(int i=0;i<Products.length;i++){
     price=0;
     price=+Products[i].price;
      }     
   }
*/
}
  

    
   
   

    
   

