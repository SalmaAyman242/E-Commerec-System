/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication11;

/**
 *
 * @author Lenovo
 */
public class ClothingProduct extends Product {
    protected String size;
    protected String frabic;
    
    public ClothingProduct(){
    
    }

    public ClothingProduct( String name,int productid,float price,String size, String frabic) {
        super(productid, name, price);
        this.size = size;
        this.frabic = frabic;
    }
    
     public void setSize(String size) {
        this.size = size;
    }

    public String getSize() {
        return size;
    }
    
    public void setFrabic(String frabic) {
        this.frabic = frabic;
    }
    

    public String getFrabic() {
        return frabic;
    }

    
    
    
    
    
    
    
}
