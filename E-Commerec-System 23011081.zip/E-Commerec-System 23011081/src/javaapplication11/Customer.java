/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication11;

/**
 *
 * @author Lenovo
 */
public class Customer{
    protected int customerid;
    protected String name;
    protected String address;
    
    public Customer(){
    
     }

    public Customer( String name,int customerid,String address) {
        this.customerid = customerid;
        this.name = name;
        this.address = address;
    }
    
    public void setCustomerid(int customerid) {
      if(customerid>0) {this.customerid = customerid;}
      else{this.customerid=Math.abs(customerid);}
    }

    public int getCustomerid() {
        return customerid;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getAddress() {
        return address;
    }

    
    
    
    
}
