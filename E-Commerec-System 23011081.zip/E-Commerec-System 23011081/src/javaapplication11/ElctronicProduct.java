/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication11;

/**
 *
 * @author Lenovo
 */
public class ElctronicProduct extends Product {
   protected String brand;
   protected int warrantyperiod;

public ElctronicProduct(){
    
}

public ElctronicProduct(String name,int productid,float price,String brand,int warrantypeperiod){
 super(productid,name,price);
 this.brand=brand;
 this.warrantyperiod=warrantyperiod;
}

     public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }
    
    public void setWarrantyperiod(int warrantyperiod) {
       if(warrantyperiod>0){ this.warrantyperiod = warrantyperiod;}
       else{this.warrantyperiod =Math.abs(warrantyperiod );}
    }

    public int getWarrantyperiod() {
        return warrantyperiod;
    }

    


   
                    
}
