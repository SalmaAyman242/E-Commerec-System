/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication11;
import java.util.Scanner;
/**
 *
 * @author Lenovo
 */
public class JavaApplication11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Welcome to E-Commere System");
        ElctronicProduct e1=new ElctronicProduct("SmartPhone",1,599.9f,"Samsung",1);
        ClothingProduct c1=new ClothingProduct("T-shirt",2,19.99f,"Medium","Cotton");
        BookProduct b1=new BookProduct("OOP",3,39.99f,"O’Reilly","O’Reilly");
        Customer customer = new Customer();
        System.out.println("Please Enter Your Name: ");
        customer.name=in.next();
        System.out.println("Please Enter Your Id: ");
        customer.customerid=in.nextInt();
        System.out.println("Please Enter Your Address: ");
        customer.address=in.next();
        Cart cart=new Cart();
        System.out.println("How Many Products You Want To Add in Your Cart? ");
        cart.setnProduct(in.nextInt());
        int addproduct;
        Order o=new Order();
        for(int i=1;i<=cart.getnProduct();i++){
        System.out.println("Which Product you Want to add: "+"\n"+"1- Smart Phone  2- T-shirt  3-OPP"  );
         addproduct=in.nextInt();
         switch(addproduct){
             case 1:
                 cart.addProduct(e1);
               break;
             case 2:
                 cart.addProduct(c1);
              break;
             case 3:
                 cart.addProduct(b1);
              break;
             }
        }
        
          o.setorderid(1);
          o.printOrderInfo();
           System.out.println(customer.customerid);
         }
        
        
        
        
    
    }
    

