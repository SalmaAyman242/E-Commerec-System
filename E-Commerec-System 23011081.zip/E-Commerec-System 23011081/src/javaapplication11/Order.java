/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication11;

/**
 *
 * @author Lenovo
 */
public class Order extends Cart{
   private int orderid;
   private double totalprice;
   public Order(){};

    public Order(int orderid, double totalprice, int customerid, int nProduct, Product[] Products) {
        super(customerid, nProduct, Products);
        this.orderid = orderid;
        this.totalprice = totalprice ;
    }
    
    public void setorderid(int orderid) {
      if(orderid>0) { this.orderid = orderid;}
      else{this.orderid=Math.abs(orderid);}
    }

    public int getorderid() {
        return orderid;
    }

    public void setTotalPrice(float totalprice) {
        if(totalprice>0){this.totalprice = totalprice;}
        else{this.totalprice=Math.abs(totalprice);}
    }

    public double getTotalPrice() {
        return totalprice;
    }
public void printOrderInfo() {
        System.out.println("Order ID: " + orderid);
        System.out.println("Customer ID: " + Products);
        System.out.println("Products:");
        for (Product product : Products) {
            if (product != null) {
                System.out.println("- " + product.getName() + " ($" + product.getPrice() + ")");
            }
        }
        System.out.println("Total Price: $" + totalprice);
        
        
}
    

   
   
                        
}
