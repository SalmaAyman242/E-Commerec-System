/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication11;

/**
 *
 * @author Lenovo
 */
public class Product {
    protected int productid;
    protected String name;
    protected float price;
    
    public Product(){
        
    }
    
    public Product(int productid,String name,float price){
       this.productid=productid;
       this.name=name;
       this.price=price;
    }
    
    public void setproductid(int productid){
     if(productid>0){this.productid=productid;}
     else{this.productid=Math.abs(productid);}
     
    }
    
    public int getproductid(){
    return productid;
    }
    
     public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

     public void setPrice(float price) {
       if(price>0){ this.price = price;}
       else{this.price=Math.abs(price);}
    }
    
    public float getPrice() {
        return price;
    }

   
    
    
}
